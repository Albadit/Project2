﻿using Cinema.page;

namespace Cinema {
    class Program {
        static void Main(string[] args) {
            Home.HomePage();
        }
    }
}